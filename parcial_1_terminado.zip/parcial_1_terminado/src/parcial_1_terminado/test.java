package parcial_1_terminado;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class test {
    
    public static void main(String[] args) throws PublicacionRepetidaException {
        // Crear una lista para la biblioteca
        List<Publicacion> publicaciones = new ArrayList<>();
        
        // Crear la biblioteca
        Biblioteca biblioteca = new Biblioteca(publicaciones);
        
        // Crear publicaciones con la información ya proporcionada
        Publicacion libro1 = new Libro("Miguel de Cervantes", Generos.FICCION, "El Quijote", 1605);
        Publicacion libro2 = new Libro("J.K. Rowling", Generos.CIENCIA, "Harry Potter y la piedra filosofal", 1997);
        Publicacion revista1 = new Revista(202, "National Geographic", 2023);
        Publicacion ilustracion1 = new Ilustracion("Vincent van Gogh", 73, 92, "La noche estrellada", 1889);
        
        // Agregar las publicaciones predeterminadas a la biblioteca
        biblioteca.agregarPublicacion(libro1);
        biblioteca.agregarPublicacion(libro2);
        biblioteca.agregarPublicacion(revista1);
        biblioteca.agregarPublicacion(ilustracion1);
        
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;
        
        while (opcion != 5) {
            // Mostrar menú
            System.out.println("Menu:");
            System.out.println("1. Mostrar todas las publicaciones");
            System.out.println("2. Leer publicaciones legibles");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine();  // Limpiar el buffer del scanner

            switch (opcion) {
                case 1:
                    // Mostrar todas las publicaciones
                    System.out.println("\nMostrando todas las publicaciones:");
                    biblioteca.mostrarPublicacion();
                    break;
                
                case 2:
                    // Leer publicaciones legibles
                    System.out.println("\nLeyendo publicaciones legibles:");
                    biblioteca.leerPublicaiones();
                    break;
                
                case 3:
                    System.out.println("Saliendo...");
                    break;
                
                default:
                    System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }

        scanner.close();
    }
}
