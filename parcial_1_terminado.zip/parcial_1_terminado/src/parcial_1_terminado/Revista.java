
package parcial_1_terminado;


class Revista extends Publicacion implements leible {
    private int edicion;

    public Revista(int edicion, String titulo, int fechaDePiblicacion) {
        super(titulo, fechaDePiblicacion);
        this.edicion = edicion;
    }

    @Override
    public String toString() {
        return "Revista: " +
               "título es '" + titulo + "', " +
               "edición es " + edicion + ", " +
               "año de publicación es " + año;
}
    
    @Override
    public void leer() {
        System.out.println("se esta leyendo la ilustracion" + titulo + "de la edicion " + edicion +"del año" + año );
    }
    }
