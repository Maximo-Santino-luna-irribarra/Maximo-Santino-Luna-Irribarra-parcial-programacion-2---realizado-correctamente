
package parcial_1_terminado;

import java.util.Objects;

public abstract class Publicacion {
    protected String titulo;
    protected int año;

    public Publicacion(String titulo, int fechaDePiblicacion) {
        this.titulo = titulo;
        this.año = fechaDePiblicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getFechaDePiblicacion() {
        return año;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 61 * hash + Objects.hashCode(this.titulo);
        hash = 61 * hash + this.año;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Publicacion other = (Publicacion) obj;
        if (this.año != other.año) {
            return false;
        }
        return Objects.equals(this.titulo, other.titulo);
    }

    @Override
    public String toString() {
        return "Publicacion{" + "titulo=" + titulo + ", fechaDePiblicacion=" + año + '}';
    }
    
    
    
}
