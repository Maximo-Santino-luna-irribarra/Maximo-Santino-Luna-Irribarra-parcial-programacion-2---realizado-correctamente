package parcial_1_terminado;
import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    protected List<Publicacion>publicaciones;

    public Biblioteca(List<Publicacion> publicaciones) {
        this.publicaciones = publicaciones;
    }

    public List<Publicacion> getPublicaciones() {
        return publicaciones;
    }
    
    public void agregarPublicacion(Publicacion publicacion)throws PublicacionRepetidaException {
        if (publicaciones.contains(publicacion)){
            throw new PublicacionRepetidaException("La publicación ya existe en la biblioteca: " + publicacion);
        }
        else{
          publicaciones.add(publicacion);
        }
    }
    public void mostrarPublicacion(){
        for (Publicacion p :publicaciones){
               System.out.println(p.toString());

        }
    }
    public void leerPublicaiones(){
        for (Publicacion p :publicaciones){
            if( p instanceof leible){
             ((leible) p).leer();
                }
            else{
                
                System.out.println("no se puede leer la ilustracion " + p.titulo);
            }
        }
    }
}

    
    
    
    
    

