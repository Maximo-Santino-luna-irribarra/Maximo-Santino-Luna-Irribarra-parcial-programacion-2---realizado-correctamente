
package parcial_1_terminado;


class Ilustracion extends Publicacion {
    private String nombreIlustrador;
    private int ancho;
    private int largo;

    public Ilustracion(String nombreIlustrador, int ancho, int largo, String titulo, int fechaDePiblicacion) {
        super(titulo, fechaDePiblicacion);
        this.nombreIlustrador = nombreIlustrador;
        this.ancho = ancho;
        this.largo = largo;
    }
    
    @Override
    public String toString() {
        return "Ilustración: " +
               "título='" + titulo + "', " +
               "ilustrador='" + nombreIlustrador + "', " +
               "dimensiones=" + ancho + "x" + largo + " cm, " +
               "año de publicación=" + año;
    }
}
