
package parcial_1_terminado;


class Libro extends Publicacion implements leible {
    private String autor;
    private Generos genero;

    public Libro(String autor, Generos genero, String titulo, int fechaDePiblicacion) {
        super(titulo, fechaDePiblicacion);
        this.autor = autor;
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Libro: " +
               "autor es " + autor + 
               ", género es " + genero + 
               ", título es " + titulo + 
               ", año es " + año;
    }
 

    @Override
    public void leer() {
        System.out.println("se esta leyendo el libro "+ titulo +"del autor"+autor+"del genero"+genero);
    }
    
}
